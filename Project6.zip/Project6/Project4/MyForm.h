#pragma once
#include <stdlib.h>
#include <string.h>
namespace Project4 {
	
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label3;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::ComboBox^  comboBox1;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::ComboBox^  comboBox2;

	private: System::Windows::Forms::ComboBox^  comboBox4;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::ComboBox^  comboBox5;

	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::ComboBox^  comboBox7;
	private: System::Windows::Forms::MonthCalendar^  monthCalendar1;
	private: System::Windows::Forms::Label^  label7;
	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->comboBox4 = (gcnew System::Windows::Forms::ComboBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->comboBox5 = (gcnew System::Windows::Forms::ComboBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->comboBox7 = (gcnew System::Windows::Forms::ComboBox());
			this->monthCalendar1 = (gcnew System::Windows::Forms::MonthCalendar());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Pixel NES", 19.8F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->ImageAlign = System::Drawing::ContentAlignment::TopCenter;
			this->label1->Location = System::Drawing::Point(228, 33);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(291, 38);
			this->label1->TabIndex = 0;
			this->label1->Text = L"RoomFinesse";
			this->label1->TextAlign = System::Drawing::ContentAlignment::TopCenter;
			this->label1->UseMnemonic = false;
			this->label1->Click += gcnew System::EventHandler(this, &MyForm::label1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(37, 97);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(57, 17);
			this->label2->TabIndex = 10;
			this->label2->Text = L"Unity ID";
			this->label2->Click += gcnew System::EventHandler(this, &MyForm::label2_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(37, 130);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(69, 17);
			this->label3->TabIndex = 11;
			this->label3->Text = L"Password";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(547, 120);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(38, 17);
			this->label4->TabIndex = 15;
			this->label4->Text = L"Date";
			this->label4->Click += gcnew System::EventHandler(this, &MyForm::label4_Click);
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(48) {
				L"12:00 PM", L"12:30 PM", L"1:00 PM", L"1:30 PM",
					L"2:00 PM", L"2:30 PM", L"3:00 PM", L"3:30 PM", L"4:00 PM", L"4:30 PM", L"5:00 PM", L"5:30 PM", L"6:00 PM", L"6:30 PM", L"7:00 PM",
					L"7:30 PM", L"8:00 PM", L"8:30 PM", L"9:00 PM", L"9:30 PM", L"10:00 PM", L"10:30 PM", L"11:00 PM", L"11:30 PM", L"12:00 AM",
					L"12:30 AM", L"1:00 AM", L"1:30 AM", L"2:00 AM", L"2:30 AM", L"3:00 AM", L"3:30 AM", L"4:00 AM", L"4:30 AM", L"5:00 AM", L"5:30 AM",
					L"6:00 AM", L"6:30 AM", L"7:00 AM", L"7:30 AM", L"8:00 AM", L"8:30 AM", L"9:00 AM", L"9:30 AM", L"10:00 AM", L"10:30 AM", L"11:00 AM",
					L"11:30 AM"
			});
			this->comboBox1->Location = System::Drawing::Point(42, 278);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(247, 24);
			this->comboBox1->TabIndex = 4;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(39, 258);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(85, 17);
			this->label5->TabIndex = 13;
			this->label5->Text = L"Time Start 1";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(113, 128);
			this->textBox1->Name = L"textBox1";
			this->textBox1->PasswordChar = '*';
			this->textBox1->Size = System::Drawing::Size(258, 22);
			this->textBox1->TabIndex = 2;
			// 
			// textBox2
			// 
			this->textBox2->AutoCompleteMode = System::Windows::Forms::AutoCompleteMode::Suggest;
			this->textBox2->AutoCompleteSource = System::Windows::Forms::AutoCompleteSource::HistoryList;
			this->textBox2->Location = System::Drawing::Point(113, 95);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(258, 22);
			this->textBox2->TabIndex = 1;
			this->textBox2->TextChanged += gcnew System::EventHandler(this, &MyForm::textBox2_TextChanged);
			// 
			// comboBox2
			// 
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(48) {
				L"12:00 PM", L"12:30 PM", L"1:00 PM", L"1:30 PM",
					L"2:00 PM", L"2:30 PM", L"3:00 PM", L"3:30 PM", L"4:00 PM", L"4:30 PM", L"5:00 PM", L"5:30 PM", L"6:00 PM", L"6:30 PM", L"7:00 PM",
					L"7:30 PM", L"8:00 PM", L"8:30 PM", L"9:00 PM", L"9:30 PM", L"10:00 PM", L"10:30 PM", L"11:00 PM", L"11:30 PM", L"12:00 AM",
					L"12:30 AM", L"1:00 AM", L"1:30 AM", L"2:00 AM", L"2:30 AM", L"3:00 AM", L"3:30 AM", L"4:00 AM", L"4:30 AM", L"5:00 AM", L"5:30 AM",
					L"6:00 AM", L"6:30 AM", L"7:00 AM", L"7:30 AM", L"8:00 AM", L"8:30 AM", L"9:00 AM", L"9:30 AM", L"10:00 AM", L"10:30 AM", L"11:00 AM",
					L"11:30 AM"
			});
			this->comboBox2->Location = System::Drawing::Point(42, 309);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(247, 24);
			this->comboBox2->TabIndex = 5;
			// 
			// comboBox4
			// 
			this->comboBox4->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox4->FormattingEnabled = true;
			this->comboBox4->Items->AddRange(gcnew cli::array< System::Object^  >(48) {
				L"12:00 PM", L"12:30 PM", L"1:00 PM", L"1:30 PM",
					L"2:00 PM", L"2:30 PM", L"3:00 PM", L"3:30 PM", L"4:00 PM", L"4:30 PM", L"5:00 PM", L"5:30 PM", L"6:00 PM", L"6:30 PM", L"7:00 PM",
					L"7:30 PM", L"8:00 PM", L"8:30 PM", L"9:00 PM", L"9:30 PM", L"10:00 PM", L"10:30 PM", L"11:00 PM", L"11:30 PM", L"12:00 AM",
					L"12:30 AM", L"1:00 AM", L"1:30 AM", L"2:00 AM", L"2:30 AM", L"3:00 AM", L"3:30 AM", L"4:00 AM", L"4:30 AM", L"5:00 AM", L"5:30 AM",
					L"6:00 AM", L"6:30 AM", L"7:00 AM", L"7:30 AM", L"8:00 AM", L"8:30 AM", L"9:00 AM", L"9:30 AM", L"10:00 AM", L"10:30 AM", L"11:00 AM",
					L"11:30 AM"
			});
			this->comboBox4->Location = System::Drawing::Point(42, 369);
			this->comboBox4->Name = L"comboBox4";
			this->comboBox4->Size = System::Drawing::Size(247, 24);
			this->comboBox4->TabIndex = 6;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(504, 404);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(130, 50);
			this->button1->TabIndex = 9;
			this->button1->Text = L"Reserve";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// comboBox5
			// 
			this->comboBox5->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox5->FormattingEnabled = true;
			this->comboBox5->Items->AddRange(gcnew cli::array< System::Object^  >(48) {
				L"12:00 PM", L"12:30 PM", L"1:00 PM", L"1:30 PM",
					L"2:00 PM", L"2:30 PM", L"3:00 PM", L"3:30 PM", L"4:00 PM", L"4:30 PM", L"5:00 PM", L"5:30 PM", L"6:00 PM", L"6:30 PM", L"7:00 PM",
					L"7:30 PM", L"8:00 PM", L"8:30 PM", L"9:00 PM", L"9:30 PM", L"10:00 PM", L"10:30 PM", L"11:00 PM", L"11:30 PM", L"12:00 AM",
					L"12:30 AM", L"1:00 AM", L"1:30 AM", L"2:00 AM", L"2:30 AM", L"3:00 AM", L"3:30 AM", L"4:00 AM", L"4:30 AM", L"5:00 AM", L"5:30 AM",
					L"6:00 AM", L"6:30 AM", L"7:00 AM", L"7:30 AM", L"8:00 AM", L"8:30 AM", L"9:00 AM", L"9:30 AM", L"10:00 AM", L"10:30 AM", L"11:00 AM",
					L"11:30 AM"
			});
			this->comboBox5->Location = System::Drawing::Point(42, 399);
			this->comboBox5->Name = L"comboBox5";
			this->comboBox5->Size = System::Drawing::Size(247, 24);
			this->comboBox5->TabIndex = 7;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(40, 191);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(45, 17);
			this->label6->TabIndex = 12;
			this->label6->Text = L"Room";
			// 
			// comboBox7
			// 
			this->comboBox7->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox7->FormattingEnabled = true;
			this->comboBox7->Items->AddRange(gcnew cli::array< System::Object^  >(13) {
				L"3rd Floor, Room C, D. H. Hill Library", L"3rd Floor, Room D, D. H. Hill Library",
					L"3rd Floor, Room E, D. H. Hill Library", L"2nd Floor, Group Study, D. H. Hill Library", L"Commons Room A, D. H. Hill Library",
					L"Commons Room B, D. H. Hill Library", L"Group Study 4510, James B. Hunt Jr. Library", L"Group Study 3208, James B. Hunt Jr. Library",
					L"Group Study 3209, James B. Hunt Jr. Library", L"Group Study 3212, James B. Hunt Jr. Library", L"Group Study 3213, James B. Hunt Jr. Library",
					L"Group Study 3214, James B. Hunt Jr. Library", L"Group Study 3215, James B. Hunt Jr. Library"
			});
			this->comboBox7->Location = System::Drawing::Point(91, 191);
			this->comboBox7->Name = L"comboBox7";
			this->comboBox7->Size = System::Drawing::Size(331, 24);
			this->comboBox7->TabIndex = 3;
			// 
			// monthCalendar1
			// 
			this->monthCalendar1->Location = System::Drawing::Point(434, 146);
			this->monthCalendar1->MaxSelectionCount = 1;
			this->monthCalendar1->Name = L"monthCalendar1";
			this->monthCalendar1->ShowTodayCircle = false;
			this->monthCalendar1->TabIndex = 8;
			this->monthCalendar1->DateChanged += gcnew System::Windows::Forms::DateRangeEventHandler(this, &MyForm::monthCalendar1_DateChanged);
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(40, 349);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(85, 17);
			this->label7->TabIndex = 14;
			this->label7->Text = L"Time Start 2";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(8, 16);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(761, 507);
			this->Controls->Add(this->label7);
			this->Controls->Add(this->comboBox7);
			this->Controls->Add(this->label6);
			this->Controls->Add(this->comboBox5);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->comboBox4);
			this->Controls->Add(this->comboBox2);
			this->Controls->Add(this->textBox2);
			this->Controls->Add(this->textBox1);
			this->Controls->Add(this->label5);
			this->Controls->Add(this->comboBox1);
			this->Controls->Add(this->label4);
			this->Controls->Add(this->monthCalendar1);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Icon = (cli::safe_cast<System::Drawing::Icon^>(resources->GetObject(L"$this.Icon")));
			this->Name = L"MyForm";
			this->Text = L"RoomFinesse";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void label2_Click(System::Object^  sender, System::EventArgs^  e) {
}
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
	String ^ studyRoom = comboBox7->Text;
	String ^ timeSlot1 = comboBox1->Text;
	String ^ timeSlot2 = comboBox2->Text;
	String ^ timeSlot3 = comboBox4->Text;
	String ^ timeSlot4 = comboBox5->Text;
	String ^ username = textBox2->Text;
	String ^ password = textBox1->Text;
	String ^ fullDate = monthCalendar1->SelectionStart.Year + "-" + monthCalendar1->SelectionStart.Month + "-" + monthCalendar1->SelectionStart.Day;
	String ^ k = "node reserve.js " + fullDate + " " + username + " " + password + " " + "\"" + studyRoom + "\"" + " " + "\"" + timeSlot1 + "\"" + " " + "\"" + timeSlot3 + "\"" + " " + "\"" + timeSlot2 + "\"" + " " + "\"" + timeSlot4 + "\"";
	char* go = new char[k->Length];
	for (int i = 0; i < k->Length; i++) {
		go[i] = k[i];
	}
	system(go);
}
private: System::Void monthCalendar1_DateChanged(System::Object^  sender, System::Windows::Forms::DateRangeEventArgs^  e) {
}
private: System::Void textBox2_TextChanged(System::Object^  sender, System::EventArgs^  e) {
}
};
}
